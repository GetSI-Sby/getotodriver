package com.rideme.driver.model;

/**
 * Created by David Studio on 27/11/2017.
 */
public class RiwayatTransaksi {

    public String id_transaksi;
    public String waktu_riwayat;
    public String nama_depan;
    public String nama_belakang;
    public String jarak;
    public int debit;
    public int kredit;
    public int saldo;
    public String tipe_transaksi;
    public String id_fitur;
    public String fitur;
    public String keterangan;
}
