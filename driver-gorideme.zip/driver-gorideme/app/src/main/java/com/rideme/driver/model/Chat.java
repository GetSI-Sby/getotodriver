package com.rideme.driver.model;

import java.io.Serializable;

/**
 * Created by David Studio on 19/10/2017.
 */
public class Chat implements Serializable{

    public String id_tujuan;
    public String nama_tujuan;
    public String reg_id_tujuan;
    public String isi_chat;
    public String waktu;
    public int status;
    public int chat_from;
    public String type;
}
