package com.rideme.driver.model;

import java.io.Serializable;

/**
 * Created by David Studio on 26/10/2017.
 */
public class Feedback implements Serializable{

    public String id;
    public String catatan;
    public long waktu;
}
